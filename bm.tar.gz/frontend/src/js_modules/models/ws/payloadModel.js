export class payloadModel {
    constructor(type, payload) {
        this.type = type,
        this.payload = payload
    }
}
