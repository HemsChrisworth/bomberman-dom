//TODO useless?
export class chatMessage {
    constructor(content) {
        this.userName = null;
        this.content = content;
        this.dateCreate = new Date()
    }
}